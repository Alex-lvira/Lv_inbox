import Box from "@mui/material/Box";
import PlayerHeader from "./components/PlayerHeader";

export default function HanabiSheet() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <PlayerHeader />
    </Box>
  );
}
